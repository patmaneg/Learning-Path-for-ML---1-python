# Learning-Path-for-ML---1-python
Learning path for Machine Learning - Python and Jupyter initials

Using Google Colab for creating jupyter notebooks

In this path I include the solutions to the exercices of the course.

Git url course:
https://github.com/elephantscale/machine-learning-learning-path/blob/master/python-data-analysis/pd-1__pandas-intro.md
